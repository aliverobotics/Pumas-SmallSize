/*
 *  main.cpp
 *  Jander
 *
 *  Created by Adalberto Llarena on 5/14/05.
 *  Copyright 2005 __MyCompanyName__. All rights reserved.
 *
 */

//velocity goes from 0 to 512
//returns the string that must be sent to robot
//vel = velocity from -512 to 512
//motorizq is true if we want the string for left motor
//str must be a ponter to a buffer for the resulting string
void give_cmd(double vel, bool motorizq, char* str)
{
	if (fabs(vel)<=512)
	{
		if (motorizq==true)
			strcpy (str, "raw 5da0");
		else
			strcpy (str, "raw 5d0a");
		
		if (vel>0) strcat (str, "01");
		else
		if (vel<0) strcat (str, "02");
		else
		strcat (str, "00");
		
		unsigned int velo=0;
		char num[4];
		
		velo = (unsigned int)fabs(floor(vel));
		sprintf (num, "%04x", velo);
		strcat (str, num);
		
		//printf ("%s ",str);
	}
	else
		str[0]='\0'; //error
}